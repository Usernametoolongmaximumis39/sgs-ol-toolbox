'use strict';
var MobileSkinSecurity = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    PRIVATE_HTTP_LIMIT: () => PRIVATE_HTTP_LIMIT,
    PRIVATE_HTTP_TIMEOUT: () => PRIVATE_HTTP_TIMEOUT,
    mobileSkinPartialLength: () => mobileSkinPartialLength,
    privateHttpRequest: () => privateHttpRequest,
    toolboxDownloadRequest: () => toolboxDownloadRequest
  });

  // src/shared/stargazing-source.js
  var STARGAZING_SITE = "https://gx.95chong.cn/";
  var STARGAZING_REPORT = STARGAZING_SITE + "api/report";
  var STARGAZING_SYNC_PATH = "/v1/stargazing/report";
  var STARGAZING_REPORT_LIMIT = 1024 * 1024;

  // src/core/mobile-skin-download.js
  var MiB = 1024 * 1024;
  var cloudRoot = "https://mres.sanguosha.cn";
  var cloudPrefix = "/update_cloud/public/";
  var pictures = /^ui\/(?:face|sface|bface|icon)\/(?:skin|char)(?:\/(?:horSkin|horChar))?\/[a-f0-9]{32}\.(?:png|jpe?g)$/i;
  var sounds = /^audio\/(?:skill|dead|effect|victory)\/[a-f0-9]{32}\.mp3$/i;
  var motion = /^ui\/face\/skin\/dynamicSkin\/[a-f0-9]{32}\.zip$/i;
  var configZips = /^\/\/config\/clients_[1-9]\d?\.\d{1,2}\.\d{1,2}_formal_\d{12}_[a-z0-9]{4,16}\/config(_list|[1-9]\d{0,2})\.zip$/;
  var pcDownload = /^\/pcgame\/81002\/[1-9]\d?\.\d{1,2}\.\d{1,2}\/(gameInfo\.json|game_\d{8,16}_\d{6,12}\.zip)$/;
  var configParams = {
    subv: "0",
    l: "0",
    ct: "windows",
    dm: "PC",
    sv: "Windows",
    vc: "1",
    pkg: "com.bf.sgs.hdexp",
    area: "0",
    is_gzip: "0",
    HWthirdAc: "0",
    astc: "0",
    config_list_inc: "1",
    is_xxtea: "1"
  };
  var installerArchiveLimit = 4294967295;
  var installerRangeLimit = 24 * MiB;
  var installerSuffixLimit = 65557;
  function validConfigQuery(params) {
    var _a, _b, _c;
    const keys = Array.from(params.keys());
    const selectors = ["c", "v", "key_v"];
    if (new Set(keys).size !== keys.length || keys.length !== Object.keys(configParams).length + selectors.length || Object.entries(configParams).some(([name, value]) => params.get(name) !== value)) return false;
    return /^(?:[A-Za-z0-9+/]{16}|[A-Za-z0-9+/]{22}==)$/.test((_a = params.get("c")) != null ? _a : "") && /^(?:[A-Za-z0-9+/]{22}==|[A-Za-z0-9+/]{27}=|[A-Za-z0-9+/]{32})$/.test((_b = params.get("v")) != null ? _b : "") && /^\d{11}$/.test((_c = params.get("key_v")) != null ? _c : "");
  }
  function installerRange(range, limit) {
    if (range && typeof range === "object") {
      const { suffix, start, end } = range, fields = Object.keys(range);
      if (fields.length === 1 && fields[0] === "suffix" && Number.isSafeInteger(suffix) && suffix >= 1 && suffix <= Math.min(limit, installerSuffixLimit)) {
        return { range: { suffix }, headers: { Range: `bytes=-${suffix}` }, limit: suffix };
      }
      if (fields.length === 2 && fields.includes("start") && fields.includes("end") && Number.isSafeInteger(start) && Number.isSafeInteger(end) && start >= 0 && end >= start && end < installerArchiveLimit && end - start + 1 <= limit) {
        return { range: { start, end }, headers: { Range: `bytes=${start}-${end}` }, limit: end - start + 1 };
      }
    }
    throw new Error("\u79FB\u52A8\u7248\u5B89\u88C5\u5305\u4EC5\u5141\u8BB8\u8BFB\u53D6\u6307\u5B9A\u7684\u6709\u9650\u533A\u95F4");
  }
  function mobileSkinRequest(value, requestedLimit, range) {
    var _a;
    let url;
    try {
      if (typeof value === "string" && value.length <= 512) url = new URL(value);
    } catch {
    }
    if (!url || url.username || url.password || value.includes("#")) throw new Error("\u79FB\u52A8\u7248\u76AE\u80A4\u8D44\u6E90\u5730\u5740\u65E0\u6548");
    const versionHost = url.origin === "https://waym.sanguosha.cn";
    const configMetadata = versionHost && url.pathname === "/config/";
    if (configMetadata ? !validConfigQuery(url.searchParams) : url.search) throw new Error("\u79FB\u52A8\u7248\u76AE\u80A4\u8D44\u6E90\u5730\u5740\u65E0\u6548");
    let max, installer = false;
    if (configMetadata) max = 128 * 1024;
    else if (versionHost && url.pathname === "/update/cloud.php") max = 16 * 1024;
    if (url.origin === cloudRoot && url.pathname.startsWith(cloudPrefix)) {
      const asset = url.pathname.slice(cloudPrefix.length);
      if (/^cloud_[1-9]\d{4,11}\.zip$/.test(asset)) max = 16 * MiB;
      else if (motion.test(asset)) max = 64 * MiB;
      else if (pictures.test(asset)) max = 12 * MiB;
      else if (sounds.test(asset)) max = 4 * MiB;
    } else if (url.origin === cloudRoot) {
      const config = configZips.exec(url.pathname);
      if (config) max = config[1] === "_list" ? 256 * 1024 : 4 * MiB;
    } else if (url.origin === "https://download.sanguosha.cn") {
      const file = (_a = pcDownload.exec(url.pathname)) == null ? void 0 : _a[1];
      if (file) {
        installer = file !== "gameInfo.json";
        max = installer ? installerRangeLimit : 16 * 1024;
      }
    }
    if (!max) throw new Error("\u79FB\u52A8\u7248\u76AE\u80A4\u8D44\u6E90\u5730\u5740\u4E0D\u5728\u6E38\u5361\u5141\u8BB8\u8303\u56F4\u5185");
    if (requestedLimit !== void 0 && (!Number.isSafeInteger(requestedLimit) || requestedLimit < 1)) {
      throw new Error("\u79FB\u52A8\u7248\u76AE\u80A4\u8D44\u6E90\u4E0B\u8F7D\u4E0A\u9650\u65E0\u6548");
    }
    if (!installer && range !== void 0) throw new Error("\u79FB\u52A8\u7248\u76AE\u80A4\u8D44\u6E90\u7C7B\u578B\u4E0D\u652F\u6301\u5206\u6BB5\u8BFB\u53D6");
    const limit = Math.min(requestedLimit != null ? requestedLimit : max, max);
    return {
      url: url.href,
      limit,
      timeout: max >= 16 * MiB ? 9e4 : 25e3,
      ...installer ? installerRange(range, limit) : {}
    };
  }
  var stargazingRequest = Object.freeze({ url: STARGAZING_REPORT, limit: MiB, timeout: 25e3, label: "\u89C2\u661F\u6570\u636E" });
  function toolboxDownloadRequest(url, limit, range) {
    if (url === STARGAZING_REPORT) {
      if (range !== void 0 || limit !== void 0 && limit !== stargazingRequest.limit) {
        throw new Error("\u89C2\u661F\u6570\u636E\u53EA\u652F\u6301\u8BFB\u53D6\u5B8C\u6574\u62A5\u544A");
      }
      return stargazingRequest;
    }
    return mobileSkinRequest(url, limit, range);
  }
  function mobileSkinPartialLength(request, status, contentRange, contentLength, contentEncoding) {
    var _a;
    if (status !== 206) throw new Error(`\u79FB\u52A8\u7248\u5B89\u88C5\u5305\u672A\u8FD4\u56DE\u6307\u5B9A\u5206\u6BB5\uFF08HTTP ${status}\uFF09`);
    const fields = /^bytes (0|[1-9]\d{0,9})-(0|[1-9]\d{0,9})\/([1-9]\d{0,9})$/i.exec(contentRange != null ? contentRange : "");
    const [start, end, total] = ((_a = fields == null ? void 0 : fields.slice(1)) != null ? _a : []).map(Number);
    const { range, limit } = request;
    const length = end - start + 1;
    if (!fields || end >= total || total > installerArchiveLimit || length < 1 || length > limit || (range.suffix === void 0 ? start !== range.start || end !== range.end : end !== total - 1 || length !== Math.min(total, range.suffix)) || contentLength != null && (!/^\d+$/.test(contentLength) || Number(contentLength) !== length) || contentEncoding != null && !/^identity$/i.test(contentEncoding)) {
      throw new Error("\u79FB\u52A8\u7248\u5B89\u88C5\u5305\u5206\u6BB5\u54CD\u5E94\u8303\u56F4\u6216\u957F\u5EA6\u65E0\u6548");
    }
    return length;
  }

  // src/shared/sync-paths.js
  var MATCH_SYNC_PATH = "/appearances/sync";
  var LEDGER_SYNC_PATH = "/ledger/sync";
  var PREFERENCES_SYNC_PATH = "/v1/preferences/sync";
  var BACKUP_READ_PATH = "/v1/backup/read";
  var BACKUP_COOLDOWN = 60 * 6e4;

  // src/shared/private-sync-http.js
  var SYNC_SOURCE_HEADER = "X-SGS-Toolbox-Origin";
  var PRIVATE_HTTP_TIMEOUT = 3e4;
  var PRIVATE_HTTP_LIMIT = 24 * 1024 * 1024;
  var privatePaths = /* @__PURE__ */ new Set([
    "/v1/proof",
    "/v1/confirm",
    "/v1/bind",
    "/v1/recover",
    "/v1/unbind",
    "/v1/private/request",
    "/v1/private/join",
    "/v1/private/release",
    "/v1/private/view",
    "/v1/private/bind-credential",
    PREFERENCES_SYNC_PATH,
    LEDGER_SYNC_PATH,
    MATCH_SYNC_PATH,
    BACKUP_READ_PATH,
    STARGAZING_SYNC_PATH
  ]);
  function privateHttpRequest({ url, body, device }, source) {
    if (typeof url !== "string" || url.length > 512 || typeof body !== "string" || body.length > PRIVATE_HTTP_LIMIT || !/^https?:\/\/(?:web\.sanguosha\.com|127\.0\.0\.1:17321)$/.test(source) || device !== void 0 && (typeof device !== "string" || !/^[a-zA-Z0-9_-]{43}$/.test(device))) throw new Error("\u79C1\u6709\u540C\u6B65\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
    const address = new URL(url);
    if (address.protocol !== "http:" || !privatePaths.has(address.pathname) || url !== address.origin + address.pathname)
      throw new Error("\u79C1\u6709\u540C\u6B65\u5730\u5740\u65E0\u6548");
    return { url, body, headers: {
      "Content-Type": "application/json",
      [SYNC_SOURCE_HEADER]: source,
      ...device && { Authorization: "Bearer " + device }
    } };
  }
  return __toCommonJS(stdin_exports);
})();

const { app, ipcMain, screen } = require('electron');
// The official shell creates its main window first. Resize it once only;
// payment/login popups and subsequent user resizing retain their own sizes.
app.once('browser-window-created', function (_, window) {
  const display = screen.getDisplayMatching(window.getBounds());
  const scale = display.scaleFactor || 1;
  const width = Math.round(Math.max(1400, display.size.width * scale / 2) / scale);
  const height = Math.round(Math.max(820, display.size.height * scale / 2) / scale);
  window.setSize(width, height);
  window.center();
});
const fs = require('fs');
const path = require('path');
const code = fs.readFileSync(path.join(__dirname, 'toolbox.js'), 'utf8');
const installedPackage = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8')); } catch (_) { return {}; } })();
const CHANNELS = [{ id: 1, name: '官服' }, { id: 3, name: '4399' }];
function channelFile() {
  let base;
  try { base = app.getPath('userData'); } catch (_) { base = process.env.APPDATA ? path.join(process.env.APPDATA, 'SGSOL') : path.join(__dirname, '..'); }
  return path.join(base, 'sgs-toolbox-channel.json');
}
function readChannel() {
  try {
    const value = JSON.parse(fs.readFileSync(channelFile(), 'utf8'));
    const packageId = Number(value && value.packageId);
    return Number.isInteger(packageId) ? packageId : null;
  } catch (_) { return null; }
}
function saveChannel(packageId) {
  const file = channelFile(), temp = file + '.tmp';
  fs.mkdirSync(path.dirname(file), { recursive: true });
  try { fs.writeFileSync(temp, JSON.stringify({ packageId }), { mode: 0o600 }); fs.renameSync(temp, file); }
  finally { try { fs.unlinkSync(temp); } catch (_) {} }
}
function channelList() {
  const login = Array.isArray(installedPackage.LoginURL) ? installedPackage.LoginURL : [];
  return CHANNELS.filter(channel => typeof login[channel.id - 1] === 'string' && login[channel.id - 1].length > 0);
}
function channelPackageId(fallback) {
  const saved = readChannel();
  if (saved !== null && channelList().some(channel => channel.id === saved)) return saved;
  const value = Number(fallback);
  return Number.isInteger(value) && value > 0 ? value : 1;
}
function channelState() {
  const channels = channelList();
  const installed = Number.isInteger(Number(installedPackage.packageId)) ? Number(installedPackage.packageId) : 1;
  const running = Number.isInteger(Number(global.PackageId)) ? Number(global.PackageId) : installed;
  const saved = readChannel();
  const selected = saved !== null && channels.some(channel => channel.id === saved) ? saved : running;
  return { running, selected, installed, channels, restartRequired: selected !== running };
}
if (typeof module !== 'undefined') module.exports = { channelPackageId };
const navigations = new Map();
const mainFrames = new Map();
const crypto = require('crypto');
const https = require('https');
const UPDATE_SOURCES = [
  'https://chk-sgstools-hangzhou.oss-cn-hangzhou.aliyuncs.com/sgs-toolbox/microclient/',
  'https://raw.githubusercontent.com/Usernametoolongmaximumis39/sgs-ol-toolbox/main/microclient/',
  'https://tools.3gs.xyz/sgs-toolbox/microclient/'
];
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const versionOf = source => { const match = /^\/\/ 三国杀OL工具箱 · 微端 (?:LITE|FULL) · (\d+\.\d+\.\d+)\r?\n/.exec(source); return match && match[1]; };
const compare = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i] ? 1 : -1; return 0; };
function updateFile() { return path.join(app.getPath('userData'), 'sgs-toolbox-script-update.json'); }
function valid(entry) { return entry && typeof entry.source === 'string' && Buffer.byteLength(entry.source) <= 12 * 1024 * 1024 && versionOf(entry.source) === entry.version && hash(entry.source) === entry.sha256; }
function loadUpdate() {
  try { const value = JSON.parse(fs.readFileSync(updateFile(), 'utf8')); return valid(value.current) && compare(value.current.version, versionOf(code) || '0.0.0') > 0 ? value : null; }
  catch (_) { return null; }
}
function saveUpdate(value) {
  const file = updateFile(), temp = file + '.tmp';
  fs.mkdirSync(path.dirname(file), { recursive: true });
  try { fs.writeFileSync(temp, JSON.stringify(value), { mode: 0o600 }); fs.renameSync(temp, file); }
  finally { try { fs.unlinkSync(temp); } catch (_) {} }
}
function startDownload(url, limit, timeout, label = '更新', resource) {
  let request;
  const promise = new Promise((resolve, reject) => {
    const receive = response => {
      let expectedLength;
      try {
        if (resource?.range) expectedLength = MobileSkinSecurity.mobileSkinPartialLength(resource, response.statusCode,
          response.headers?.['content-range'], response.headers?.['content-length'], response.headers?.['content-encoding']);
        else if (response.statusCode !== 200) { response.resume(); reject(new Error(label + '服务器返回 ' + response.statusCode)); return; }
        if (Number(response.headers?.['content-length']) > limit) throw new Error(label + '文件过大');
      } catch (error) { request.destroy(error); return; }
      const chunks = []; let size = 0;
      response.on('data', chunk => {
        size += chunk.length;
        if (size > (expectedLength ?? limit)) request.destroy(new Error(label + '文件过大'));
        else chunks.push(chunk);
      });
      response.on('end', () => {
        if (expectedLength !== undefined && size !== expectedLength) reject(new Error('移动版安装包分段响应长度不符'));
        else resolve(Buffer.concat(chunks));
      });
      response.on('error', reject);
    };
    request = resource?.headers ? https.get(url, { headers: { ...resource.headers, 'Accept-Encoding': 'identity' } }, receive) : https.get(url, receive);
    const deadline = setTimeout(() => request.destroy(new Error(label + '下载超时')), timeout);
    request.once('close', () => clearTimeout(deadline));
    request.on('error', reject);
  });
  return { promise, cancel() { request?.destroy(new Error(label + '下载已取消')); } };
}
function download(url, limit, timeout) {
  return startDownload(url, limit, timeout).promise;
}
let updating = false;
async function updateScript(action) {
  if (!['check', 'install', 'rollback'].includes(action)) throw new Error('未知更新操作');
  if (updating) throw new Error('正在更新，请稍候');
  updating = true;
  try {
    const saved = loadUpdate(), current = saved ? saved.current : { source: code, version: versionOf(code) || '0.0.0', sha256: hash(code) };
    if (action === 'rollback') {
      if (!saved || !valid(saved.previous)) throw new Error('没有可回退的脚本');
      // Never persist an older script than the installed host baseline.
      if (compare(saved.previous.version, versionOf(code) || '0.0.0') < 0) throw new Error('旧脚本低于安装版本');
      saveUpdate({ current: saved.previous }); return { version: saved.previous.version, pending: true, rollback: false };
    }
    const errors = [];
    for (const base of UPDATE_SOURCES) {
      try {
        const manifest = JSON.parse((await download(base + 'update.json', 16384, 10000)).toString('utf8'));
        if (manifest.format !== 'sgs-toolbox-script-v1' || manifest.hostApi !== 1 || !/^\d+\.\d+\.\d+$/.test(manifest.version) || !/^[a-f0-9]{64}$/.test(manifest.sha256) || !Number.isInteger(manifest.bytes) || manifest.bytes < 1 || manifest.bytes > 12 * 1024 * 1024) throw new Error('脚本更新清单无效或需要新版接入层');
        const newer = compare(manifest.version, current.version) > 0;
        if (action === 'check' || !newer) return { version: manifest.version, current: current.version, newer, rollback: !!(saved && valid(saved.previous)) };
        const bytes = await download(base + 'toolbox.js', 12 * 1024 * 1024, 20000);
        const next = { version: manifest.version, sha256: manifest.sha256, source: bytes.toString('utf8') };
        if (bytes.length !== manifest.bytes || hash(bytes) !== manifest.sha256 || !valid(next) || !next.source.startsWith('// 三国杀OL工具箱 · 微端 LITE · ')) throw new Error('脚本版本或摘要校验失败');
        new (require('vm').Script)(next.source); // Parse only; never run remote code in the main process.
        saveUpdate({ current: next, previous: current });
        return { version: next.version, pending: true, rollback: true };
      } catch (error) {
        const detail = error.code === 'ETIMEDOUT' ? '连接超时' : error.message;
        errors.push(new URL(base).hostname + '（' + detail + '）');
      }
    }
    throw new Error('脚本更新失败：' + errors.join('；'));
  } finally { updating = false; }
}
function allowed(event) {
  const url = event.senderFrame ? event.senderFrame.url : navigations.get(event.sender.id) || event.sender.getURL();
  const frame = event.senderFrame ? null : mainFrames.get(event.sender.id);
  return isGameURL(url) && (event.senderFrame ? !event.senderFrame.parent : !!frame && event.frameId === frame.routingId && event.sender.getProcessId() === frame.processId);
}
ipcMain.handle('sgs-toolbox:update:v1', async (event, action) => {
  if (!allowed(event)) throw new Error('仅允许官方游戏主页面更新工具箱');
  return updateScript(action);
});
const mobileSkinJobs = new WeakMap();
ipcMain.handle('sgs-toolbox:mobile-skin:v1', async (event, message) => {
  if (!allowed(event)) throw new Error('仅允许官方游戏主页面读取移动版皮肤');
  const { id, url, limit, range } = message ?? {};
  if (typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw new Error('无效的移动版皮肤下载请求');
  // This validator is bundled before host.cjs by build-microclient.mjs.
  const request = MobileSkinSecurity.toolboxDownloadRequest(url, limit, range);
  const label = request.label || '移动版皮肤资源';
  let jobs = mobileSkinJobs.get(event.sender);
  if (!jobs) mobileSkinJobs.set(event.sender, jobs = new Map());
  if (jobs.has(id) || jobs.size >= 24) throw new Error(`${label}下载请求过多，请稍后重试`);
  const job = startDownload(request.url, request.limit, request.timeout, label, request);
  jobs.set(id, job);
  try {
    const bytes = await job.promise;
    return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  } finally { jobs.delete(id); }
});
ipcMain.on('sgs-toolbox:mobile-skin-cancel:v1', (event, id) => {
  if (allowed(event)) mobileSkinJobs.get(event.sender)?.get(id)?.cancel();
});
const privateSyncJobs = new WeakMap();
ipcMain.handle('sgs-toolbox:private-sync-http:v1', async (event, message) => {
  if (!allowed(event) || !/^[a-f0-9]{32}$/.test(message?.id ?? '')) throw new Error('无效的私有同步请求');
  const origin = new URL(event.senderFrame?.url || navigations.get(event.sender.id) || event.sender.getURL()).origin;
  const { url, headers, body } = MobileSkinSecurity.privateHttpRequest(message, origin);
  const { PRIVATE_HTTP_LIMIT: limit, PRIVATE_HTTP_TIMEOUT: timeout } = MobileSkinSecurity;
  let jobs = privateSyncJobs.get(event.sender);
  if (!jobs) privateSyncJobs.set(event.sender, jobs = new Map());
  if (jobs.has(message.id) || jobs.size >= 12 || Buffer.byteLength(body) > limit) throw new Error('私有同步请求超限');
  let request, timer;
  try {
    return await new Promise((resolve, reject) => {
      request = require('http').request(url, { method: 'POST', headers: { ...headers, 'Content-Length': Buffer.byteLength(body) } }, response => {
        const chunks = [];
        let bytes = 0;
        response.on('data', chunk => {
          bytes += chunk.length;
          if (bytes > limit) request.destroy(new Error('私有同步响应超限'));
          else chunks.push(chunk);
        });
        response.once('error', reject);
        response.once('end', () => resolve({ status: response.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      request.once('error', reject);
      jobs.set(message.id, request);
      timer = setTimeout(() => request.destroy(new Error('私有同步请求超时')), timeout);
      request.end(body);
    });
  } finally { clearTimeout(timer); jobs.delete(message.id); }
});
ipcMain.on('sgs-toolbox:private-sync-http-cancel:v1', (event, id) => {
  if (allowed(event)) privateSyncJobs.get(event.sender)?.get(id)?.destroy(new Error('私有同步请求已取消'));
});
ipcMain.handle('sgs-toolbox:channel-shell:v1', (event, request) => {
  const url = event.senderFrame ? event.senderFrame.url : event.sender.getURL();
  if (!/^file:/i.test(url) || !/index_wd\.html(?:[?#]|$)/i.test(url)) throw new Error('仅允许微端外壳切换游戏渠道');
  if (!request || typeof request !== 'object') throw new Error('无效的渠道请求');
  if (request.action === 'get') return channelState();
  if (request.action !== 'set') throw new Error('未知渠道操作');
  const packageId = Number(request.packageId);
  if (!Number.isInteger(packageId) || !channelList().some(channel => channel.id === packageId)) throw new Error('当前客户端不包含该游戏渠道');
  saveChannel(packageId);
  return channelState();
});
// Electron 10 getURL() can still return the previous document during preload.
// Record the actual main-frame navigation before the new preload requests source.
app.on('web-contents-created', function (_, contents) {
  const id = contents.id;
  const remember = function (_, url, _inPlace, mainFrame, processId, routingId) { if (mainFrame) { navigations.set(id, url); mainFrames.set(id, { processId, routingId }); } };
  contents.on('did-start-navigation', remember);
  contents.on('will-redirect', remember);
  contents.on('did-frame-navigate', function (_, url, _status, _text, mainFrame, processId, routingId) { remember(_, url, false, mainFrame, processId, routingId); });
  const cancelSkinJobs = () => { for (const job of mobileSkinJobs.get(contents)?.values() ?? []) job.cancel(); };
  contents.on('did-start-navigation', (_, _url, inPlace, mainFrame) => { if (mainFrame && !inPlace) cancelSkinJobs(); });
  contents.once('destroyed', function () { cancelSkinJobs(); navigations.delete(id); mainFrames.delete(id); });
});
function isGameURL(value) {
  try {
    const url = new URL(value);
    return ['https:', 'http:'].includes(url.protocol) && url.hostname === 'web.sanguosha.com'
      && /^\/220\/h5_2\/index(?:_\d+)?\.php$/.test(url.pathname);
  } catch (_) { return false; }
}
ipcMain.on('sgs-toolbox:source:v1', event => {
  // Only the official OL game guest, never a login/payment/third-party frame.
  const url = event.senderFrame ? event.senderFrame.url : navigations.get(event.sender.id) || event.sender.getURL();
  const topLevel = !event.senderFrame || !event.senderFrame.parent;
  event.returnValue = isGameURL(url) && topLevel ? (loadUpdate()?.current.source || code) : '';
});

// Read only the official cashier endpoints; never forward cookies or execute HTML.
function cashierURL(value, initial = true) {
  const u = new URL(value);
  const gateway = u.origin === 'https://openapi.alipay.com' && u.pathname === '/gateway.do';
  const cashier = u.origin === 'https://excashier.alipay.com' && u.pathname === '/standard/auth.htm';
  const assignment = u.origin === 'https://unitradeprod.alipay.com' && u.pathname === '/appAssign.htm';
  const method = u.searchParams.get('method');
  // Redirects may return to the gateway without repeating the original method.
  // Keep the initiating request strict and validate every redirect endpoint.
  if (u.username || u.password || !(gateway || cashier || assignment) || (initial && (!gateway || method !== 'alipay.trade.page.pay')) || (gateway && method && method !== 'alipay.trade.page.pay')) {
    const host = u.hostname.replace(/[^a-z0-9.-]/gi, '').slice(0, 100);
    const route = u.pathname.replace(/[^a-z0-9/_.-]/gi, '_').slice(0, 100);
    throw Error('支付宝收银台' + (initial ? '入口' : '跳转') + '地址异常（域名：' + host + '；路径：' + route + '）');
  }
  return u.href;
}
function readCashier(value, redirects = 0) {
  const url = cashierURL(value, redirects === 0);
  return new Promise((resolve, reject) => {
    const req = https.get(url, res => {
      if ([301,302,303,307,308].includes(res.statusCode)) {
        res.resume();
        if (redirects >= 4) return reject(Error('支付宝跳转次数过多'));
        try { resolve(readCashier(new URL(res.headers.location, url).href, redirects + 1)); } catch (e) { reject(e); }
        return;
      }
      if (res.statusCode !== 200) { res.resume(); reject(Error('支付宝收银台 HTTP ' + res.statusCode)); return; }
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > 2 * 1024 * 1024) req.destroy(Error('支付宝收银台内容过大')); else chunks.push(chunk); });
      res.on('error', reject);
      res.on('end', () => resolve({status:200, finalUrl:url, responseText:Buffer.concat(chunks).toString('utf8')}));
    });
    req.setTimeout(12000, () => req.destroy(Error('支付宝收银台读取超时')));
    req.on('error', reject);
  });
}
ipcMain.handle('sgs-toolbox:alipay:v1', (event, url) => {
  if (!allowed(event)) throw Error('仅允许官方游戏主页面解析付款码');
  return readCashier(url);
});
